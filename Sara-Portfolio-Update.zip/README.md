# Sara’s Portfolio

Three linked pages: Home, Projects, and About / Contact.

## Design
- Palette: ivory `#f7f6f0`, forest green `#223b32`, clay `#a35439`.
- Google Fonts: Playfair Display for headings; DM Sans for body text.
- Shared `styles.css` uses type, class, and ID selectors and an 8px spacing scale.
- CSS Grid provides multi-column sections; Flexbox arranges navigation and actions.
- Media queries at 960px and 600px adapt the layout for desktop, tablet, and mobile.

## GitHub Pages
In repository Settings → Pages, select **Deploy from a branch**, then choose **main** and **/ (root)** and click Save.

Expected site address: https://sugarmama2005.github.io/about-me-html2/

## Browser checks
Open each page in browser DevTools device emulation at widths of **320px**, **768px**, and **1200px**. Verify navigation, text readability, image sizing, and absence of horizontal scrolling.

Local file checks passed: all relative page links, CSS references, and image paths resolve. Automated browser checks could not run because the browser download was unavailable; the device-emulation check above is still required.
